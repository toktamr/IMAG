/* This file was generated with JastAdd2 (http://jastadd.org) version 2.1.3 */
package AST;

import java.util.*;
/**
 * @ast node
 * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/StateMachine.ast:8
 * @production State : {@link Declaration} ::= <span class="component">&lt;Label:String&gt;</span>;

 */
public class State extends Declaration implements Cloneable {
  /**
   * @apilevel internal
   */
  public State clone() throws CloneNotSupportedException {
    State node = (State) super.clone();
    node.alreadyDeclared_visited = false;
    node.multiplyDeclared_visited = false;
    node.hasLaterNamesake_visited = false;
    node.altTransitions_visited = false;
    node.successors_visited = false;
    node.localLookup_String_visited = null;
    node.reachable_visited = -1;
    node.reachable_computed = false;
    node.reachable_initialized = false;
    node.reachable_value = null;
    node.transitionsOf_State_visited = null;
    return node;
  }
  /**
   * @apilevel internal
   */
  public State copy() {
    try {
      State node = (State) clone();
      node.parent = null;
      if(children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   */
  public State fullCopy() {
    State tree = (State) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if(child != null) {
          child = child.fullCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * @aspect PrettyPrint
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrettyPrint.jrag:14
   */
  public void pp() {
    System.out.println("state "+getLabel()+";");
  }
  /**
   * @aspect PrintInfoAboutCycles
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrintInfoAboutCycles.jrag:12
   */
  public void printInfoAboutCycles() {
    System.out.print("State "+getLabel()+" is ");
    if (!reachable().contains(this)) {
      System.out.print("not ");
    }
    System.out.println("on a cycle.");
  }
  /**
   * @aspect PrintReachable
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrintReachable.jrag:10
   */
  public void printReachable() {
    System.out.println(getLabel() + " can reach {" +
        listOfReachableStateLabels() + "}");
  }
  /**
   * @aspect PrintReachable
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrintReachable.jrag:15
   */
  public String listOfReachableStateLabels() {
    boolean insideList = false;
    StringBuffer result = new StringBuffer();
    for (State s : reachable()) {
      if (insideList)
        result.append(", ");
      else
        insideList = true;
      result.append(s.getLabel());
    }
    return result.toString();
  }
  /**
   */
  public State() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   */
  public void init$Children() {
  }
  /**
   */
  public State(String p0) {
    setLabel(p0);
  }
  /**
   */
  public State(beaver.Symbol p0) {
    setLabel(p0);
  }
  /**
   * @apilevel low-level
   */
  protected int numChildren() {
    return 0;
  }
  /**
   * @apilevel low-level
   */
  public void flushCache() {
    super.flushCache();
    alreadyDeclared_visited = false;
    multiplyDeclared_visited = false;
    hasLaterNamesake_visited = false;
    altTransitions_visited = false;
    successors_visited = false;
    localLookup_String_visited = null;
    reachable_visited = -1;
    reachable_computed = false;
    reachable_initialized = false;
    reachable_value = null;
    transitionsOf_State_visited = null;
    State_altSuccessors_visited = false;
    State_altSuccessors_computed = false;
    State_altSuccessors_value = null;
        State_altSuccessors_contributors = null;
    State_predecessors_visited = false;
    State_predecessors_computed = false;
    State_predecessors_value = null;
        State_predecessors_contributors = null;
    State_altReachable_visited = -1;
    State_altReachable_computed = false;
    State_altReachable_initialized = false;
    State_altReachable_value = null;
        State_altReachable_contributors = null;
    State_transitions_visited = false;
    State_transitions_computed = false;
    State_transitions_value = null;
        State_transitions_contributors = null;
  }
  /**
   * @apilevel internal
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();
    State_altSuccessors_visited = false;
    State_altSuccessors_computed = false;
    State_altSuccessors_value = null;
        State_altSuccessors_contributors = null;
    State_predecessors_visited = false;
    State_predecessors_computed = false;
    State_predecessors_value = null;
        State_predecessors_contributors = null;
    State_altReachable_visited = -1;
    State_altReachable_computed = false;
    State_altReachable_initialized = false;
    State_altReachable_value = null;
        State_altReachable_contributors = null;
    State_transitions_visited = false;
    State_transitions_computed = false;
    State_transitions_value = null;
        State_transitions_contributors = null;
  }
  /**
   * Replaces the lexeme Label.
   * @param value The new value for the lexeme Label.
   * @apilevel high-level
   */
  public void setLabel(String value) {
    tokenString_Label = value;
  }
  /**
   * @apilevel internal
   */
  protected String tokenString_Label;
  /**
   */
  public int Labelstart;
  /**
   */
  public int Labelend;
  /**
   * JastAdd-internal setter for lexeme Label using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Label
   * @apilevel internal
   */
  public void setLabel(beaver.Symbol symbol) {
    if(symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setLabel is only valid for String lexemes");
    tokenString_Label = (String)symbol.value;
    Labelstart = symbol.getStart();
    Labelend = symbol.getEnd();
  }
  /**
   * Retrieves the value for the lexeme Label.
   * @return The value for the lexeme Label.
   * @apilevel high-level
   */
  public String getLabel() {
    return tokenString_Label != null ? tokenString_Label : "";
  }
  /**
   * @apilevel internal
   */
  protected boolean alreadyDeclared_visited = false;
  /**
   * @attribute syn
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:6
   */
  public boolean alreadyDeclared() {
    if (alreadyDeclared_visited) {
      throw new RuntimeException("Circular definition of attr: alreadyDeclared in class: org.jastadd.ast.AST.SynDecl");
    }
    alreadyDeclared_visited = true;
    try {  return lookup(this.getLabel()) != this;  }
    finally {
      alreadyDeclared_visited = false;
    }
  }
  /**
   * @apilevel internal
   */
  protected boolean multiplyDeclared_visited = false;
  /**
   * @attribute syn
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:9
   */
  public boolean multiplyDeclared() {
    if (multiplyDeclared_visited) {
      throw new RuntimeException("Circular definition of attr: multiplyDeclared in class: org.jastadd.ast.AST.SynDecl");
    }
    multiplyDeclared_visited = true;
    try {  return alreadyDeclared() || hasLaterNamesake();  }
    finally {
      multiplyDeclared_visited = false;
    }
  }
  /**
   * @apilevel internal
   */
  protected boolean hasLaterNamesake_visited = false;
  /**
   * @attribute syn
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:12
   */
  public boolean hasLaterNamesake() {
    if (hasLaterNamesake_visited) {
      throw new RuntimeException("Circular definition of attr: hasLaterNamesake in class: org.jastadd.ast.AST.SynDecl");
    }
    hasLaterNamesake_visited = true;
    try {  return lookupForward(getLabel()) != null;  }
    finally {
      hasLaterNamesake_visited = false;
    }
  }
  /**
   * @apilevel internal
   */
  protected boolean altTransitions_visited = false;
  /**
   * @attribute syn
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:27
   */
  public Set<Transition> altTransitions() {
    if (altTransitions_visited) {
      throw new RuntimeException("Circular definition of attr: altTransitions in class: org.jastadd.ast.AST.SynDecl");
    }
    altTransitions_visited = true;
    try {  return transitionsOf(this);  }
    finally {
      altTransitions_visited = false;
    }
  }
  /**
   * @apilevel internal
   */
  protected boolean successors_visited = false;
  /**
   * @attribute syn
   * @aspect Graph
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Graph.jrag:13
   */
  public Set<State> successors() {
    if (successors_visited) {
      throw new RuntimeException("Circular definition of attr: successors in class: org.jastadd.ast.AST.SynDecl");
    }
    successors_visited = true;
    try {
        Set<State> result = new HashSet<State>();
        for (Transition t : transitions()) {
          if (t.target() != null) result.add(t.target());
        }
        return result;
      }
    finally {
      successors_visited = false;
    }
  }
  /**
   * @apilevel internal
   */
  protected java.util.Set localLookup_String_visited;
  /**
   * @attribute syn
   * @aspect NameAnalysis
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/NameAnalysis.jrag:18
   */
  public State localLookup(String label) {
    Object _parameters = label;
    if(localLookup_String_visited == null) localLookup_String_visited = new java.util.HashSet(4);
    if (localLookup_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attr: localLookup in class: org.jastadd.ast.AST.SynDecl");
    }
    localLookup_String_visited.add(_parameters);
    try {  return // R6
          (label.equals(getLabel())) ? this : null;  }
    finally {
      localLookup_String_visited.remove(_parameters);
    }
  }
  /**
   * @apilevel internal
   */
  protected int reachable_visited = -1;
  /**
   * @apilevel internal
   */
  protected boolean reachable_computed = false;
  /**
   * @apilevel internal
   */
  protected boolean reachable_initialized = false;
  /**
   * @apilevel internal
   */
  protected Set<State> reachable_value;
  /**
   * @attribute syn
   * @aspect Reachability
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Reachability.jrag:9
   */
  public Set<State> reachable() {
    if(reachable_computed) {
      return reachable_value;
    }
    ASTNode$State state = state();
    if (!reachable_initialized) {
      reachable_initialized = true;
      reachable_value = new HashSet<State>();
    }
    if (!state.IN_CIRCLE) {
      state.IN_CIRCLE = true;
      // TODO: fixme
      // state().CIRCLE_INDEX = 1;
      do {
        reachable_visited = state.CIRCLE_INDEX;
        state.CHANGE = false;
        Set<State> new_reachable_value = reachable_compute();
        if ((new_reachable_value==null && reachable_value!=null) || (new_reachable_value!=null && !new_reachable_value.equals(reachable_value))) {
          state.CHANGE = true;
        }
        reachable_value = new_reachable_value;
        state.CIRCLE_INDEX++;
      } while (state.CHANGE);
      if(true) {
        reachable_computed = true;
        state.LAST_CYCLE = true;
        reachable_compute();
        state.LAST_CYCLE = false;
      } else {
        state.RESET_CYCLE = true;
        reachable_compute();
        state.RESET_CYCLE = false;
        reachable_computed = false;
        reachable_initialized = false;
      }
      state.IN_CIRCLE = false;
      return reachable_value;
    }
    if(reachable_visited != state.CIRCLE_INDEX) {
      reachable_visited = state.CIRCLE_INDEX;
      if (state.LAST_CYCLE) {
      reachable_computed = true;
        Set<State> new_reachable_value = reachable_compute();
        return new_reachable_value;
      }
      if (state.RESET_CYCLE) {
        reachable_computed = false;
        reachable_initialized = false;
        reachable_visited = -1;
        return reachable_value;
      }
      Set<State> new_reachable_value = reachable_compute();
      if ((new_reachable_value==null && reachable_value!=null) || (new_reachable_value!=null && !new_reachable_value.equals(reachable_value))) {
        state.CHANGE = true;
      }
      reachable_value = new_reachable_value;
      return reachable_value;
    }
    return reachable_value;
  }
  /**
   * @apilevel internal
   */
  private Set<State> reachable_compute() { // R2
      HashSet<State> result = new HashSet<State>();
      for (State s : successors()) {
        result.add(s);
        result.addAll(s.reachable());
      }
      return result;
    }
  /**
   * @attribute inh
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:28
   */
  public Set<Transition> transitionsOf(State s) {
    Object _parameters = s;
    if(transitionsOf_State_visited == null) transitionsOf_State_visited = new java.util.HashSet(4);
    if (transitionsOf_State_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attr: transitionsOf in class: org.jastadd.ast.AST.InhDecl");
    }
    transitionsOf_State_visited.add(_parameters);
    Set<Transition> transitionsOf_State_value = getParent().Define_Set_Transition__transitionsOf(this, null, s);

    transitionsOf_State_visited.remove(_parameters);
    return transitionsOf_State_value;
  }
  /**
   * @apilevel internal
   */
  protected java.util.Set transitionsOf_State_visited;
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:48
   */
  public Set<State> altSuccessors() {
    if(State_altSuccessors_computed) {
      return State_altSuccessors_value;
    }
    if (State_altSuccessors_visited) {
      throw new RuntimeException("Circular definition of attr: altSuccessors in class: org.jastadd.ast.AST.CollDecl");
    }
    State_altSuccessors_visited = true;
    State_altSuccessors_value = altSuccessors_compute();
    if(true) {
      State_altSuccessors_computed = true;
    } else {
    }

    State_altSuccessors_visited = false;
    return State_altSuccessors_value;
  }
  java.util.Set State_altSuccessors_contributors;

  /**
   * @apilevel internal
   * @return the contributor set for altSuccessors
   */
  public java.util.Set State_altSuccessors_contributors() {
    if(State_altSuccessors_contributors == null)
      State_altSuccessors_contributors  = new ASTNode$State.IdentityHashSet(4);
    return State_altSuccessors_contributors;
  }

  /**
   * @apilevel internal
   */
  private Set<State> altSuccessors_compute() {
    ASTNode node = this;
    while(node.getParent() != null && !(node instanceof StateMachine)) {
      node = node.getParent();
    }
    StateMachine root = (StateMachine) node;
    root.collect_contributors_State_altSuccessors();
    State_altSuccessors_value = new HashSet<State>();
    if(State_altSuccessors_contributors != null)
    for (java.util.Iterator iter = State_altSuccessors_contributors.iterator(); iter.hasNext(); ) {
      ASTNode contributor = (ASTNode) iter.next();
      contributor.contributeTo_State_State_altSuccessors(State_altSuccessors_value);
    }
    // TODO: disabled temporarily since collections may not be cached
    //State_altSuccessors_contributors = null;
    return State_altSuccessors_value;
  }
  /**
   * @apilevel internal
   */
  protected boolean State_altSuccessors_visited = false;
  /**
   * @apilevel internal
   */
  protected boolean State_altSuccessors_computed = false;
  /**
   * @apilevel internal
   */
  protected Set<State> State_altSuccessors_value;
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:57
   */
  public Set<State> predecessors() {
    if(State_predecessors_computed) {
      return State_predecessors_value;
    }
    if (State_predecessors_visited) {
      throw new RuntimeException("Circular definition of attr: predecessors in class: org.jastadd.ast.AST.CollDecl");
    }
    State_predecessors_visited = true;
    State_predecessors_value = predecessors_compute();
    if(true) {
      State_predecessors_computed = true;
    } else {
    }

    State_predecessors_visited = false;
    return State_predecessors_value;
  }
  java.util.Set State_predecessors_contributors;

  /**
   * @apilevel internal
   * @return the contributor set for predecessors
   */
  public java.util.Set State_predecessors_contributors() {
    if(State_predecessors_contributors == null)
      State_predecessors_contributors  = new ASTNode$State.IdentityHashSet(4);
    return State_predecessors_contributors;
  }

  /**
   * @apilevel internal
   */
  private Set<State> predecessors_compute() {
    ASTNode node = this;
    while(node.getParent() != null && !(node instanceof StateMachine)) {
      node = node.getParent();
    }
    StateMachine root = (StateMachine) node;
    root.collect_contributors_State_predecessors();
    State_predecessors_value = new HashSet<State>();
    if(State_predecessors_contributors != null)
    for (java.util.Iterator iter = State_predecessors_contributors.iterator(); iter.hasNext(); ) {
      ASTNode contributor = (ASTNode) iter.next();
      contributor.contributeTo_State_State_predecessors(State_predecessors_value);
    }
    // TODO: disabled temporarily since collections may not be cached
    //State_predecessors_contributors = null;
    return State_predecessors_value;
  }
  /**
   * @apilevel internal
   */
  protected boolean State_predecessors_visited = false;
  /**
   * @apilevel internal
   */
  protected boolean State_predecessors_computed = false;
  /**
   * @apilevel internal
   */
  protected Set<State> State_predecessors_value;
  /**
   * @apilevel internal
   */
  protected int State_altReachable_visited = -1;
  /**
   * @apilevel internal
   */
  protected boolean State_altReachable_computed = false;

  /**
   * @apilevel internal
   */
  protected boolean State_altReachable_initialized = false;

  /**
   * @apilevel internal
   */
  protected Set<State> State_altReachable_value;


  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:102
   */
  public Set<State> altReachable() {
    if(State_altReachable_computed) {
      return State_altReachable_value;
    }
    ASTNode node = this;
    while(node.getParent() != null && !(node instanceof StateMachine))
      node = node.getParent();
    StateMachine root = (StateMachine) node;

    if(root.collecting_contributors_State_altReachable)
      throw new RuntimeException("Circularity during phase 1");
    root.collect_contributors_State_altReachable();

    if (!State_altReachable_initialized) {
      State_altReachable_initialized = true;
      State_altReachable_value = new HashSet<State>();
    }

    if (!state().IN_CIRCLE) {
      state().IN_CIRCLE = true;
      state().CIRCLE_INDEX = 1;
      do {
        State_altReachable_visited = state().CIRCLE_INDEX;
        state().CHANGE = false;

        Set<State> new_State_altReachable_value = new HashSet<State>();
        combine_State_altReachable_contributions(new_State_altReachable_value);
        if ((new_State_altReachable_value==null && State_altReachable_value!=null) || (new_State_altReachable_value!=null && !new_State_altReachable_value.equals(State_altReachable_value))) {
          state().CHANGE = true;
        }
        State_altReachable_value = new_State_altReachable_value;
        state().CIRCLE_INDEX++;
      } while (state().CHANGE);

      if(true) {
        State_altReachable_computed = true;
        state.LAST_CYCLE = true;
        State_altReachable_value = combine_State_altReachable_contributions(new HashSet<State>());
        state.LAST_CYCLE = false;
      } else {
        state.RESET_CYCLE = true;
        State_altReachable_value = combine_State_altReachable_contributions(new HashSet<State>());
        state.RESET_CYCLE = false;
        State_altReachable_computed = false;
        State_altReachable_initialized = false;
      }
      state().IN_CIRCLE = false;
      return State_altReachable_value;
    }
    if(State_altReachable_visited != state().CIRCLE_INDEX) {
      State_altReachable_visited = state().CIRCLE_INDEX;
      if (state.LAST_CYCLE) {
      State_altReachable_computed = true;
        Set<State> new_State_altReachable_value = State_altReachable_value = combine_State_altReachable_contributions(new HashSet<State>());
        return new_State_altReachable_value;
      }
      if (state.RESET_CYCLE) {
        State_altReachable_computed = false;
        State_altReachable_initialized = false;
        State_altReachable_visited = -1;
        return State_altReachable_value;
      }
      Set<State> new_State_altReachable_value = new HashSet<State>();
      combine_State_altReachable_contributions(new_State_altReachable_value);
      if ((new_State_altReachable_value==null && State_altReachable_value!=null) || (new_State_altReachable_value!=null && !new_State_altReachable_value.equals(State_altReachable_value))) {
        state().CHANGE = true;
      }
      State_altReachable_value = new_State_altReachable_value;
      return State_altReachable_value;
    }
    return State_altReachable_value;
  }
  java.util.Set State_altReachable_contributors;

  /**
   * @apilevel internal
   * @return the contributor set for altReachable
   */
  public java.util.Set State_altReachable_contributors() {
    if(State_altReachable_contributors == null)
      State_altReachable_contributors  = new ASTNode$State.IdentityHashSet(4);
    return State_altReachable_contributors;
  }

  private Set<State> combine_State_altReachable_contributions(Set<State> h) {
    if(State_altReachable_contributors != null)
    for(java.util.Iterator iter = State_altReachable_contributors.iterator(); iter.hasNext(); ) {
      ASTNode contributor = (ASTNode) iter.next();
      contributor.contributeTo_State_State_altReachable(h);
    }
    // TODO: disabled temporarily since collections may not be cached
    //State_altReachable_contributors = null;
    return h;
  }
  /**
   * @attribute coll
   * @aspect Graph
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Graph.jrag:6
   */
  public Set<Transition> transitions() {
    if(State_transitions_computed) {
      return State_transitions_value;
    }
    if (State_transitions_visited) {
      throw new RuntimeException("Circular definition of attr: transitions in class: org.jastadd.ast.AST.CollDecl");
    }
    State_transitions_visited = true;
    State_transitions_value = transitions_compute();
    if(true) {
      State_transitions_computed = true;
    } else {
    }

    State_transitions_visited = false;
    return State_transitions_value;
  }
  java.util.Set State_transitions_contributors;

  /**
   * @apilevel internal
   * @return the contributor set for transitions
   */
  public java.util.Set State_transitions_contributors() {
    if(State_transitions_contributors == null)
      State_transitions_contributors  = new ASTNode$State.IdentityHashSet(4);
    return State_transitions_contributors;
  }

  /**
   * @apilevel internal
   */
  private Set<Transition> transitions_compute() {
    ASTNode node = this;
    while(node.getParent() != null && !(node instanceof StateMachine)) {
      node = node.getParent();
    }
    StateMachine root = (StateMachine) node;
    root.collect_contributors_State_transitions();
    State_transitions_value = new HashSet<Transition>();
    if(State_transitions_contributors != null)
    for (java.util.Iterator iter = State_transitions_contributors.iterator(); iter.hasNext(); ) {
      ASTNode contributor = (ASTNode) iter.next();
      contributor.contributeTo_State_State_transitions(State_transitions_value);
    }
    // TODO: disabled temporarily since collections may not be cached
    //State_transitions_contributors = null;
    return State_transitions_value;
  }
  /**
   * @apilevel internal
   */
  protected boolean State_transitions_visited = false;
  /**
   * @apilevel internal
   */
  protected boolean State_transitions_computed = false;
  /**
   * @apilevel internal
   */
  protected Set<Transition> State_transitions_value;
  protected void collect_contributors_State_predecessors() {
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:59
   */
      for(java.util.Iterator iter = (successors()).iterator(); iter.hasNext(); ) {
        State ref = (State) iter.next();
        if (ref != null) {
          ref.State_predecessors_contributors().add(this);
        }
      }
    super.collect_contributors_State_predecessors();
  }
  protected void collect_contributors_StateMachine_errors() {
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:86
   */
    if (alreadyDeclared()) {
      {
        StateMachine ref = (StateMachine) (theMachine());
        if (ref != null) {
          ref.StateMachine_errors_contributors().add(this);
        }
      }
    }
    super.collect_contributors_StateMachine_errors();
  }
  protected void collect_contributors_State_altReachable() {
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:104
   */
      for(java.util.Iterator iter = (predecessors()).iterator(); iter.hasNext(); ) {
        State ref = (State) iter.next();
        if (ref != null) {
          ref.State_altReachable_contributors().add(this);
        }
      }
    super.collect_contributors_State_altReachable();
  }
  protected void contributeTo_State_State_predecessors(Set<State> collection) {
    super.contributeTo_State_State_predecessors(collection);
    collection.add(this);
  }

  protected void contributeTo_StateMachine_StateMachine_errors(Set<String> collection) {
    super.contributeTo_StateMachine_StateMachine_errors(collection);
    if(alreadyDeclared())
      collection.add(getLabel()+" is already declared");
  }

  protected void contributeTo_State_State_altReachable(Set<State> collection) {
    super.contributeTo_State_State_altReachable(collection);
    collection.addAll(union(asSet(this),altReachable()));
  }

}
