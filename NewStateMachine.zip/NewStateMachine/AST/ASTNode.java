/* This file was generated with JastAdd2 (http://jastadd.org) version 2.1.3 */
package AST;

import java.util.*;
/**
 * @ast node
 * @production ASTNode;

 */
public class ASTNode<T extends ASTNode> extends beaver.Symbol  implements Cloneable, Iterable<T> {
  /**
   * @apilevel internal
   */
  public ASTNode<T> clone() throws CloneNotSupportedException {
    ASTNode node = (ASTNode) super.clone();
    return node;
  }
  /**
   * @apilevel internal
   */
  public ASTNode<T> copy() {
    try {
      ASTNode node = (ASTNode) clone();
      node.parent = null;
      if(children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   */
  public ASTNode<T> fullCopy() {
    ASTNode tree = (ASTNode) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if(child != null) {
          child = child.fullCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:109
   */
  Set<State> asSet(State o) {
    HashSet<State> result = new HashSet<State>();
    result.add(o);
    return result;
  }
  /**
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:115
   */
  Set<State> union(Set<State> s1, Set<State> s2) {
    HashSet<State> result = new HashSet<State>();
    for (State s: s1) result.add(s);
    for (State s: s2) result.add(s);
    return result;
  }
  /**
   */
  public ASTNode() {
    super();
    init$Children();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   */
  public void init$Children() {
  }
  /**
   * @apilevel internal
   */
  private int childIndex;
  /**
   * @apilevel low-level
   */
  public int getIndexOfChild(ASTNode node) {
    if (node == null) {
      return -1;
    }
    if (node.childIndex < numChildren && node == children[node.childIndex]) {
      return node.childIndex;
    }
    for(int i = 0; children != null && i < children.length; i++) {
      if(children[i] == node) {
        node.childIndex = i;
        return i;
      }
    }
    return -1;
  }
  /**
   * @apilevel internal
   */
  public static final boolean generatedWithCircularEnabled = true;
  /**
   * @apilevel internal
   */
  public static final boolean generatedWithCacheCycle = true;
  /**
   * @apilevel internal
   */
  public static final boolean generatedWithComponentCheck = false;
  /**
   * Parent pointer
   * @apilevel low-level
   */
  protected ASTNode parent;
  /**
   * Child array
   * @apilevel low-level
   */
  protected ASTNode[] children;
  /**
   * @apilevel internal
   */
  protected static ASTNode$State state = new ASTNode$State();
  /**
   * @apilevel internal
   */
  public final ASTNode$State state() {
    return state;
  }
  /**
   * @apilevel low-level
   */
  public T getChild(int i) {

    // No rewrites
    ASTNode child = getChildNoTransform(i);
    return (T) child;

  }
  /**
   * @apilevel low-level
   */
  public void addChild(T node) {
    setChild(node, getNumChildNoTransform());
  }
  /**
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @apilevel low-level
   */
  public final T getChildNoTransform(int i) {
    if (children == null) {
      return null;
    }
    T child = (T)children[i];
    return child;
  }
  /**
   * @apilevel low-level
   */
  protected int numChildren;
  /**
   * @apilevel low-level
   */
  protected int numChildren() {
    return numChildren;
  }
  /**
   * @apilevel low-level
   */
  public int getNumChild() {
    return numChildren();
  }
  /**
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @apilevel low-level
   */
  public final int getNumChildNoTransform() {
    return numChildren();
  }
  /**
   * @apilevel low-level
   */
  public void setChild(ASTNode node, int i) {
    if(children == null) {
      children = new ASTNode[(i+1>4 || !(this instanceof List))?i+1:4];
    } else if (i >= children.length) {
      ASTNode c[] = new ASTNode[i << 1];
      System.arraycopy(children, 0, c, 0, children.length);
      children = c;
    }
    children[i] = node;
    if(i >= numChildren) {
      numChildren = i+1;
    }
    if(node != null) {
      node.setParent(this);
      node.childIndex = i;
    }
  }
  /**
   * @apilevel low-level
   */
  public void insertChild(ASTNode node, int i) {
    if(children == null) {
      children = new ASTNode[(i+1>4 || !(this instanceof List))?i+1:4];
      children[i] = node;
    } else {
      ASTNode c[] = new ASTNode[children.length + 1];
      System.arraycopy(children, 0, c, 0, i);
      c[i] = node;
      if(i < children.length) {
        System.arraycopy(children, i, c, i+1, children.length-i);
        for(int j = i+1; j < c.length; ++j) {
          if(c[j] != null) {
            c[j].childIndex = j;
          }
        }
      }
      children = c;
    }
    numChildren++;
    if(node != null) {
      node.setParent(this);
      node.childIndex = i;
    }
  }
  /**
   * @apilevel low-level
   */
  public void removeChild(int i) {
    if(children != null) {
      ASTNode child = (ASTNode) children[i];
      if(child != null) {
        child.parent = null;
        child.childIndex = -1;
      }
      // Adding a check of this instance to make sure its a List, a move of children doesn't make
      // any sense for a node unless its a list. Also, there is a problem if a child of a non-List node is removed
      // and siblings are moved one step to the right, with null at the end.
      if (this instanceof List || this instanceof Opt) {
        System.arraycopy(children, i+1, children, i, children.length-i-1);
        children[children.length-1] = null;
        numChildren--;
        // fix child indices
        for(int j = i; j < numChildren; ++j) {
          if(children[j] != null) {
            child = (ASTNode) children[j];
            child.childIndex = j;
          }
        }
      } else {
        children[i] = null;
      }
    }
  }
  /**
   * @apilevel low-level
   */
  public ASTNode getParent() {
    ;
    return (ASTNode) parent;
  }
  /**
   * @apilevel low-level
   */
  public void setParent(ASTNode node) {
    parent = node;
  }
  /**
   * Line and column information.
   */
  protected int startLine;
  /**
   */
  protected short startColumn;
  /**
   */
  protected int endLine;
  /**
   */
  protected short endColumn;
  /**
   */
  public int getStartLine() {
    return startLine;
  }
  /**
   */
  public short getStartColumn() {
    return startColumn;
  }
  /**
   */
  public int getEndLine() {
    return endLine;
  }
  /**
   */
  public short getEndColumn() {
    return endColumn;
  }
  /**
   */
  public void setStart(int startLine, short startColumn) {
    this.startLine = startLine;
    this.startColumn = startColumn;
  }
  /**
   */
  public void setEnd(int endLine, short endColumn) {
    this.endLine = endLine;
    this.endColumn = endColumn;
  }
  /**
   * @apilevel low-level
   */
  public java.util.Iterator<T> iterator() {
    return new java.util.Iterator<T>() {
      private int counter = 0;
      public boolean hasNext() {
        return counter < getNumChild();
      }
      public T next() {
        if(hasNext())
          return (T)getChild(counter++);
        else
          return null;
      }
      public void remove() {
        throw new UnsupportedOperationException();
      }
    };
  }
  /**
   * @apilevel low-level
   */
  public void flushCache() {
  }
  /**
   * @apilevel internal
   */
  public void flushCollectionCache() {
  }
  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:66
   */
    protected void collect_contributors_StateMachine_numberOfTransitionsColl() {
    for(int i = 0; i < getNumChild(); i++) {
      getChild(i).collect_contributors_StateMachine_numberOfTransitionsColl();
    }
  }
  protected void contributeTo_StateMachine_StateMachine_numberOfTransitionsColl(Counter collection) {
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:83
   */
    protected void collect_contributors_StateMachine_errors() {
    for(int i = 0; i < getNumChild(); i++) {
      getChild(i).collect_contributors_StateMachine_errors();
    }
  }
  protected void contributeTo_StateMachine_StateMachine_errors(Set<String> collection) {
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:48
   */
    protected void collect_contributors_State_altSuccessors() {
    for(int i = 0; i < getNumChild(); i++) {
      getChild(i).collect_contributors_State_altSuccessors();
    }
  }
  protected void contributeTo_State_State_altSuccessors(Set<State> collection) {
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:57
   */
    protected void collect_contributors_State_predecessors() {
    for(int i = 0; i < getNumChild(); i++) {
      getChild(i).collect_contributors_State_predecessors();
    }
  }
  protected void contributeTo_State_State_predecessors(Set<State> collection) {
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:102
   */
    protected void collect_contributors_State_altReachable() {
    for(int i = 0; i < getNumChild(); i++) {
      getChild(i).collect_contributors_State_altReachable();
    }
  }
  protected void contributeTo_State_State_altReachable(Set<State> collection) {
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Graph.jrag:6
   */
    protected void collect_contributors_State_transitions() {
    for(int i = 0; i < getNumChild(); i++) {
      getChild(i).collect_contributors_State_transitions();
    }
  }
  protected void contributeTo_State_State_transitions(Set<Transition> collection) {
  }

  /**
   * @apilevel internal
   */
  public State Define_State_lookupForward(ASTNode caller, ASTNode child, String label) {
    return getParent().Define_State_lookupForward(this, caller, label);
  }
  /**
   * @apilevel internal
   */
  public Set<Transition> Define_Set_Transition__transitionsOf(ASTNode caller, ASTNode child, State s) {
    return getParent().Define_Set_Transition__transitionsOf(this, caller, s);
  }
  /**
   * @apilevel internal
   */
  public StateMachine Define_StateMachine_theMachine(ASTNode caller, ASTNode child) {
    return getParent().Define_StateMachine_theMachine(this, caller);
  }
  /**
   * @apilevel internal
   */
  public State Define_State_lookup(ASTNode caller, ASTNode child, String label) {
    return getParent().Define_State_lookup(this, caller, label);
  }
}
