/* This file was generated with JastAdd2 (http://jastadd.org) version 2.1.3 */
package AST;

import java.util.*;
/**
 * @ast node
 * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/StateMachine.ast:6
 * @production StateMachine : {@link ASTNode} ::= <span class="component">{@link Declaration}*</span>;

 */
public class StateMachine extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @apilevel internal
   */
  public StateMachine clone() throws CloneNotSupportedException {
    StateMachine node = (StateMachine) super.clone();
    node.numberOfTransitions_visited = false;
    return node;
  }
  /**
   * @apilevel internal
   */
  public StateMachine copy() {
    try {
      StateMachine node = (StateMachine) clone();
      node.parent = null;
      if(children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   */
  public StateMachine fullCopy() {
    StateMachine tree = (StateMachine) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if(child != null) {
          child = child.fullCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * @aspect PrettyPrint
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrettyPrint.jrag:6
   */
  public void pp() {
    for (Declaration d:getDeclarationList()) {
      d.pp();
    }
  }
  /**
   * @aspect PrintInfoAboutCycles
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrintInfoAboutCycles.jrag:4
   */
  public void printInfoAboutCycles() {
    for (Declaration d : getDeclarationList()) {
      d.printInfoAboutCycles();
    }
  }
  /**
   * @aspect PrintReachable
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrintReachable.jrag:4
   */
  public void printReachable() {
    for (Declaration d : getDeclarations()) d.printReachable();
  }
  /**
   */
  public StateMachine() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   */
  public void init$Children() {
    children = new ASTNode[1];
    setChild(new List(), 0);
  }
  /**
   */
  public StateMachine(List<Declaration> p0) {
    setChild(p0, 0);
  }
  /**
   * @apilevel low-level
   */
  protected int numChildren() {
    return 1;
  }
  /**
   * @apilevel low-level
   */
  public void flushCache() {
    super.flushCache();
    numberOfTransitions_visited = false;
    StateMachine_numberOfTransitionsColl_visited = false;
    StateMachine_numberOfTransitionsColl_computed = false;
    StateMachine_numberOfTransitionsColl_value = null;
        StateMachine_numberOfTransitionsColl_contributors = null;
    StateMachine_errors_visited = false;
    StateMachine_errors_computed = false;
    StateMachine_errors_value = null;
        StateMachine_errors_contributors = null;
        collect_contributors_StateMachine_numberOfTransitionsColl = false;
        collect_contributors_StateMachine_errors = false;
        collect_contributors_State_altSuccessors = false;
        collect_contributors_State_predecessors = false;
        collect_contributors_State_altReachable = false;
        collecting_contributors_State_altReachable = false;
        collect_contributors_State_transitions = false;
  }
  /**
   * @apilevel internal
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();
    StateMachine_numberOfTransitionsColl_visited = false;
    StateMachine_numberOfTransitionsColl_computed = false;
    StateMachine_numberOfTransitionsColl_value = null;
        StateMachine_numberOfTransitionsColl_contributors = null;
    StateMachine_errors_visited = false;
    StateMachine_errors_computed = false;
    StateMachine_errors_value = null;
        StateMachine_errors_contributors = null;
        collect_contributors_StateMachine_numberOfTransitionsColl = false;
        collect_contributors_StateMachine_errors = false;
        collect_contributors_State_altSuccessors = false;
        collect_contributors_State_predecessors = false;
        collect_contributors_State_altReachable = false;
        collecting_contributors_State_altReachable = false;
        collect_contributors_State_transitions = false;
  }
  /**
   * Replaces the Declaration list.
   * @param list The new list node to be used as the Declaration list.
   * @apilevel high-level
   */
  public void setDeclarationList(List<Declaration> list) {
    setChild(list, 0);
  }
  /**
   * Retrieves the number of children in the Declaration list.
   * @return Number of children in the Declaration list.
   * @apilevel high-level
   */
  public int getNumDeclaration() {
    return getDeclarationList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Declaration list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Declaration list.
   * @apilevel low-level
   */
  public int getNumDeclarationNoTransform() {
    return getDeclarationListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Declaration list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Declaration list.
   * @apilevel high-level
   */
  public Declaration getDeclaration(int i) {
    return (Declaration) getDeclarationList().getChild(i);
  }
  /**
   * Check whether the Declaration list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasDeclaration() {
    return getDeclarationList().getNumChild() != 0;
  }
  /**
   * Append an element to the Declaration list.
   * @param node The element to append to the Declaration list.
   * @apilevel high-level
   */
  public void addDeclaration(Declaration node) {
    List<Declaration> list = (parent == null || state == null) ? getDeclarationListNoTransform() : getDeclarationList();
    list.addChild(node);
  }
  /**
   * @apilevel low-level
   */
  public void addDeclarationNoTransform(Declaration node) {
    List<Declaration> list = getDeclarationListNoTransform();
    list.addChild(node);
  }
  /**
   * Replaces the Declaration list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public void setDeclaration(Declaration node, int i) {
    List<Declaration> list = getDeclarationList();
    list.setChild(node, i);
  }
  /**
   * Retrieves the Declaration list.
   * @return The node representing the Declaration list.
   * @apilevel high-level
   */
  public List<Declaration> getDeclarationList() {
    List<Declaration> list = (List<Declaration>) getChild(0);
    list.getNumChild();
    return list;
  }
  /**
   * Retrieves the Declaration list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Declaration list.
   * @apilevel low-level
   */
  public List<Declaration> getDeclarationListNoTransform() {
    return (List<Declaration>) getChildNoTransform(0);
  }
  /**
   * Retrieves the Declaration list.
   * @return The node representing the Declaration list.
   * @apilevel high-level
   */
  public List<Declaration> getDeclarations() {
    return getDeclarationList();
  }
  /**
   * Retrieves the Declaration list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Declaration list.
   * @apilevel low-level
   */
  public List<Declaration> getDeclarationsNoTransform() {
    return getDeclarationListNoTransform();
  }
  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:66
   */
    private boolean collect_contributors_StateMachine_numberOfTransitionsColl = false;
  protected void collect_contributors_StateMachine_numberOfTransitionsColl() {
    if(collect_contributors_StateMachine_numberOfTransitionsColl) return;
    super.collect_contributors_StateMachine_numberOfTransitionsColl();
    collect_contributors_StateMachine_numberOfTransitionsColl = true;
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:83
   */
    private boolean collect_contributors_StateMachine_errors = false;
  protected void collect_contributors_StateMachine_errors() {
    if(collect_contributors_StateMachine_errors) return;
    super.collect_contributors_StateMachine_errors();
    collect_contributors_StateMachine_errors = true;
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:48
   */
    private boolean collect_contributors_State_altSuccessors = false;
  protected void collect_contributors_State_altSuccessors() {
    if(collect_contributors_State_altSuccessors) return;
    super.collect_contributors_State_altSuccessors();
    collect_contributors_State_altSuccessors = true;
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:57
   */
    private boolean collect_contributors_State_predecessors = false;
  protected void collect_contributors_State_predecessors() {
    if(collect_contributors_State_predecessors) return;
    super.collect_contributors_State_predecessors();
    collect_contributors_State_predecessors = true;
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:102
   */
    private boolean collect_contributors_State_altReachable = false;

  public boolean collecting_contributors_State_altReachable = false;

  protected void collect_contributors_State_altReachable() {
    if (!collect_contributors_State_altReachable) {
      collecting_contributors_State_altReachable = true;
      super.collect_contributors_State_altReachable();
      collecting_contributors_State_altReachable = false;
      collect_contributors_State_altReachable = true;
    }
  }

  /**
   * @aspect <NoAspect>
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Graph.jrag:6
   */
    private boolean collect_contributors_State_transitions = false;
  protected void collect_contributors_State_transitions() {
    if(collect_contributors_State_transitions) return;
    super.collect_contributors_State_transitions();
    collect_contributors_State_transitions = true;
  }

  /**
   * @apilevel internal
   */
  protected boolean numberOfTransitions_visited = false;
  /**
   * @attribute syn
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:64
   */
  public int numberOfTransitions() {
    if (numberOfTransitions_visited) {
      throw new RuntimeException("Circular definition of attr: numberOfTransitions in class: org.jastadd.ast.AST.SynDecl");
    }
    numberOfTransitions_visited = true;
    try {  return numberOfTransitionsColl().value();  }
    finally {
      numberOfTransitions_visited = false;
    }
  }
  /**
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:17
   * @apilevel internal
   */
  public State Define_State_lookupForward(ASTNode caller, ASTNode child, String label) {
    if (caller == getDeclarationListNoTransform()) {
      int i = caller.getIndexOfChild(child);
      {
    for (int k = i+1; k<getNumDeclaration(); k++) {
      Declaration d = getDeclaration(k);
      State match = d.localLookup(label);
      if (match != null) return match;
    }
    return null;
  }
    }
    else {
      return getParent().Define_State_lookupForward(this, caller, label);
    }
  }
  /**
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:30
   * @apilevel internal
   */
  public Set<Transition> Define_Set_Transition__transitionsOf(ASTNode caller, ASTNode child, State s) {
    if (caller == getDeclarationListNoTransform()) {
      int i = caller.getIndexOfChild(child);
      {
    HashSet<Transition> result = new HashSet<Transition>();
    for (Declaration d : getDeclarationList()) {
      Transition t = d.transitionOf(s);
      if (t != null) result.add(t);
    }
    return result;
  }
    }
    else {
      return getParent().Define_Set_Transition__transitionsOf(this, caller, s);
    }
  }
  /**
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:73
   * @apilevel internal
   */
  public StateMachine Define_StateMachine_theMachine(ASTNode caller, ASTNode child) {
    if (caller == getDeclarationListNoTransform()) {
      int i = caller.getIndexOfChild(child);
      return this;
    }
    else {
      return getParent().Define_StateMachine_theMachine(this, caller);
    }
  }
  /**
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/NameAnalysis.jrag:10
   * @apilevel internal
   */
  public State Define_State_lookup(ASTNode caller, ASTNode child, String label) {
    if (caller == getDeclarationListNoTransform()) {
      int i = caller.getIndexOfChild(child);
      { // R4
    for (Declaration d : getDeclarationList()) {
      State match = d.localLookup(label);
      if (match != null) return match;
    }
    return null;
  }
    }
    else {
      return getParent().Define_State_lookup(this, caller, label);
    }
  }
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:66
   */
  public Counter numberOfTransitionsColl() {
    if(StateMachine_numberOfTransitionsColl_computed) {
      return StateMachine_numberOfTransitionsColl_value;
    }
    if (StateMachine_numberOfTransitionsColl_visited) {
      throw new RuntimeException("Circular definition of attr: numberOfTransitionsColl in class: org.jastadd.ast.AST.CollDecl");
    }
    StateMachine_numberOfTransitionsColl_visited = true;
    StateMachine_numberOfTransitionsColl_value = numberOfTransitionsColl_compute();
    if(true) {
      StateMachine_numberOfTransitionsColl_computed = true;
    } else {
    }

    StateMachine_numberOfTransitionsColl_visited = false;
    return StateMachine_numberOfTransitionsColl_value;
  }
  java.util.Set StateMachine_numberOfTransitionsColl_contributors;

  /**
   * @apilevel internal
   * @return the contributor set for numberOfTransitionsColl
   */
  public java.util.Set StateMachine_numberOfTransitionsColl_contributors() {
    if(StateMachine_numberOfTransitionsColl_contributors == null)
      StateMachine_numberOfTransitionsColl_contributors  = new ASTNode$State.IdentityHashSet(4);
    return StateMachine_numberOfTransitionsColl_contributors;
  }

  /**
   * @apilevel internal
   */
  private Counter numberOfTransitionsColl_compute() {
    ASTNode node = this;
    while(node.getParent() != null && !(node instanceof StateMachine)) {
      node = node.getParent();
    }
    StateMachine root = (StateMachine) node;
    root.collect_contributors_StateMachine_numberOfTransitionsColl();
    StateMachine_numberOfTransitionsColl_value = new Counter();
    if(StateMachine_numberOfTransitionsColl_contributors != null)
    for (java.util.Iterator iter = StateMachine_numberOfTransitionsColl_contributors.iterator(); iter.hasNext(); ) {
      ASTNode contributor = (ASTNode) iter.next();
      contributor.contributeTo_StateMachine_StateMachine_numberOfTransitionsColl(StateMachine_numberOfTransitionsColl_value);
    }
    // TODO: disabled temporarily since collections may not be cached
    //StateMachine_numberOfTransitionsColl_contributors = null;
    return StateMachine_numberOfTransitionsColl_value;
  }
  /**
   * @apilevel internal
   */
  protected boolean StateMachine_numberOfTransitionsColl_visited = false;
  /**
   * @apilevel internal
   */
  protected boolean StateMachine_numberOfTransitionsColl_computed = false;
  /**
   * @apilevel internal
   */
  protected Counter StateMachine_numberOfTransitionsColl_value;
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:83
   */
  public Set<String> errors() {
    if(StateMachine_errors_computed) {
      return StateMachine_errors_value;
    }
    if (StateMachine_errors_visited) {
      throw new RuntimeException("Circular definition of attr: errors in class: org.jastadd.ast.AST.CollDecl");
    }
    StateMachine_errors_visited = true;
    StateMachine_errors_value = errors_compute();
    if(true) {
      StateMachine_errors_computed = true;
    } else {
    }

    StateMachine_errors_visited = false;
    return StateMachine_errors_value;
  }
  java.util.Set StateMachine_errors_contributors;

  /**
   * @apilevel internal
   * @return the contributor set for errors
   */
  public java.util.Set StateMachine_errors_contributors() {
    if(StateMachine_errors_contributors == null)
      StateMachine_errors_contributors  = new ASTNode$State.IdentityHashSet(4);
    return StateMachine_errors_contributors;
  }

  /**
   * @apilevel internal
   */
  private Set<String> errors_compute() {
    ASTNode node = this;
    while(node.getParent() != null && !(node instanceof StateMachine)) {
      node = node.getParent();
    }
    StateMachine root = (StateMachine) node;
    root.collect_contributors_StateMachine_errors();
    StateMachine_errors_value = new HashSet<String>();
    if(StateMachine_errors_contributors != null)
    for (java.util.Iterator iter = StateMachine_errors_contributors.iterator(); iter.hasNext(); ) {
      ASTNode contributor = (ASTNode) iter.next();
      contributor.contributeTo_StateMachine_StateMachine_errors(StateMachine_errors_value);
    }
    // TODO: disabled temporarily since collections may not be cached
    //StateMachine_errors_contributors = null;
    return StateMachine_errors_value;
  }
  /**
   * @apilevel internal
   */
  protected boolean StateMachine_errors_visited = false;
  /**
   * @apilevel internal
   */
  protected boolean StateMachine_errors_computed = false;
  /**
   * @apilevel internal
   */
  protected Set<String> StateMachine_errors_value;
}
