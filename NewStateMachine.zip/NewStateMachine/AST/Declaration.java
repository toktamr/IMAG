/* This file was generated with JastAdd2 (http://jastadd.org) version 2.1.3 */
package AST;

import java.util.*;
/**
 * @ast node
 * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/StateMachine.ast:7
 * @production Declaration : {@link ASTNode};

 */
public abstract class Declaration extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @apilevel internal
   */
  public Declaration clone() throws CloneNotSupportedException {
    Declaration node = (Declaration) super.clone();
    node.transitionOf_State_visited = null;
    node.localLookup_String_visited = null;
    node.lookupForward_String_visited = null;
    node.theMachine_visited = false;
    node.lookup_String_visited = null;
    return node;
  }
  /**
   * @aspect PrettyPrint
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrettyPrint.jrag:12
   */
  public void pp() {}
  /**
   * @aspect PrintInfoAboutCycles
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrintInfoAboutCycles.jrag:10
   */
  public void printInfoAboutCycles() {}
  /**
   * @aspect PrintReachable
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrintReachable.jrag:8
   */
  public void printReachable() { }
  /**
   */
  public Declaration() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   */
  public void init$Children() {
  }
  /**
   * @apilevel low-level
   */
  protected int numChildren() {
    return 0;
  }
  /**
   * @apilevel low-level
   */
  public void flushCache() {
    super.flushCache();
    transitionOf_State_visited = null;
    localLookup_String_visited = null;
    lookupForward_String_visited = null;
    theMachine_visited = false;
    lookup_String_visited = null;
  }
  /**
   * @apilevel internal
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();
  }
  /**
   * @apilevel internal
   */
  protected java.util.Set transitionOf_State_visited;
  /**
   * @attribute syn
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:39
   */
  public Transition transitionOf(State s) {
    Object _parameters = s;
    if(transitionOf_State_visited == null) transitionOf_State_visited = new java.util.HashSet(4);
    if (transitionOf_State_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attr: transitionOf in class: org.jastadd.ast.AST.SynDecl");
    }
    transitionOf_State_visited.add(_parameters);
    try {  return null;  }
    finally {
      transitionOf_State_visited.remove(_parameters);
    }
  }
  /**
   * @apilevel internal
   */
  protected java.util.Set localLookup_String_visited;
  /**
   * @attribute syn
   * @aspect NameAnalysis
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/NameAnalysis.jrag:18
   */
  public State localLookup(String label) {
    Object _parameters = label;
    if(localLookup_String_visited == null) localLookup_String_visited = new java.util.HashSet(4);
    if (localLookup_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attr: localLookup in class: org.jastadd.ast.AST.SynDecl");
    }
    localLookup_String_visited.add(_parameters);
    try {  return null;  }
    finally {
      localLookup_String_visited.remove(_parameters);
    }
  }
  /**
   * @attribute inh
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:15
   */
  public State lookupForward(String label) {
    Object _parameters = label;
    if(lookupForward_String_visited == null) lookupForward_String_visited = new java.util.HashSet(4);
    if (lookupForward_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attr: lookupForward in class: org.jastadd.ast.AST.InhDecl");
    }
    lookupForward_String_visited.add(_parameters);
    State lookupForward_String_value = getParent().Define_State_lookupForward(this, null, label);

    lookupForward_String_visited.remove(_parameters);
    return lookupForward_String_value;
  }
  /**
   * @apilevel internal
   */
  protected java.util.Set lookupForward_String_visited;
  /**
   * @attribute inh
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:72
   */
  public StateMachine theMachine() {
    if (theMachine_visited) {
      throw new RuntimeException("Circular definition of attr: theMachine in class: org.jastadd.ast.AST.InhDecl");
    }
    theMachine_visited = true;
    StateMachine theMachine_value = getParent().Define_StateMachine_theMachine(this, null);

    theMachine_visited = false;
    return theMachine_value;
  }
  /**
   * @apilevel internal
   */
  protected boolean theMachine_visited = false;
  /**
   * @attribute inh
   * @aspect NameAnalysis
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/NameAnalysis.jrag:8
   */
  public State lookup(String label) {
    Object _parameters = label;
    if(lookup_String_visited == null) lookup_String_visited = new java.util.HashSet(4);
    if (lookup_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attr: lookup in class: org.jastadd.ast.AST.InhDecl");
    }
    lookup_String_visited.add(_parameters);
    State lookup_String_value = getParent().Define_State_lookup(this, null, label);

    lookup_String_visited.remove(_parameters);
    return lookup_String_value;
  }
  /**
   * @apilevel internal
   */
  protected java.util.Set lookup_String_visited;
}
