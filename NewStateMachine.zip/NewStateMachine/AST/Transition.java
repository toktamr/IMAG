/* This file was generated with JastAdd2 (http://jastadd.org) version 2.1.3 */
package AST;

import java.util.*;
/**
 * @ast node
 * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/StateMachine.ast:9
 * @production Transition : {@link Declaration} ::= <span class="component">&lt;Label:String&gt;</span> <span class="component">&lt;SourceLabel:String&gt;</span> <span class="component">&lt;TargetLabel:String&gt;</span>;

 */
public class Transition extends Declaration implements Cloneable {
  /**
   * @apilevel internal
   */
  public Transition clone() throws CloneNotSupportedException {
    Transition node = (Transition) super.clone();
    node.transitionOf_State_visited = null;
    node.source_visited = false;
    node.target_visited = false;
    return node;
  }
  /**
   * @apilevel internal
   */
  public Transition copy() {
    try {
      Transition node = (Transition) clone();
      node.parent = null;
      if(children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   */
  public Transition fullCopy() {
    Transition tree = (Transition) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if(child != null) {
          child = child.fullCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * @aspect PrettyPrint
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/PrettyPrint.jrag:18
   */
  public void pp() {
    System.out.println("trans "+getLabel()+":"+getSourceLabel()+"->"+getTargetLabel()+";");
  }
  /**
   */
  public Transition() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   */
  public void init$Children() {
  }
  /**
   */
  public Transition(String p0, String p1, String p2) {
    setLabel(p0);
    setSourceLabel(p1);
    setTargetLabel(p2);
  }
  /**
   */
  public Transition(beaver.Symbol p0, beaver.Symbol p1, beaver.Symbol p2) {
    setLabel(p0);
    setSourceLabel(p1);
    setTargetLabel(p2);
  }
  /**
   * @apilevel low-level
   */
  protected int numChildren() {
    return 0;
  }
  /**
   * @apilevel low-level
   */
  public void flushCache() {
    super.flushCache();
    transitionOf_State_visited = null;
    source_visited = false;
    target_visited = false;
  }
  /**
   * @apilevel internal
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();
  }
  /**
   * Replaces the lexeme Label.
   * @param value The new value for the lexeme Label.
   * @apilevel high-level
   */
  public void setLabel(String value) {
    tokenString_Label = value;
  }
  /**
   * @apilevel internal
   */
  protected String tokenString_Label;
  /**
   */
  public int Labelstart;
  /**
   */
  public int Labelend;
  /**
   * JastAdd-internal setter for lexeme Label using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Label
   * @apilevel internal
   */
  public void setLabel(beaver.Symbol symbol) {
    if(symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setLabel is only valid for String lexemes");
    tokenString_Label = (String)symbol.value;
    Labelstart = symbol.getStart();
    Labelend = symbol.getEnd();
  }
  /**
   * Retrieves the value for the lexeme Label.
   * @return The value for the lexeme Label.
   * @apilevel high-level
   */
  public String getLabel() {
    return tokenString_Label != null ? tokenString_Label : "";
  }
  /**
   * Replaces the lexeme SourceLabel.
   * @param value The new value for the lexeme SourceLabel.
   * @apilevel high-level
   */
  public void setSourceLabel(String value) {
    tokenString_SourceLabel = value;
  }
  /**
   * @apilevel internal
   */
  protected String tokenString_SourceLabel;
  /**
   */
  public int SourceLabelstart;
  /**
   */
  public int SourceLabelend;
  /**
   * JastAdd-internal setter for lexeme SourceLabel using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme SourceLabel
   * @apilevel internal
   */
  public void setSourceLabel(beaver.Symbol symbol) {
    if(symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setSourceLabel is only valid for String lexemes");
    tokenString_SourceLabel = (String)symbol.value;
    SourceLabelstart = symbol.getStart();
    SourceLabelend = symbol.getEnd();
  }
  /**
   * Retrieves the value for the lexeme SourceLabel.
   * @return The value for the lexeme SourceLabel.
   * @apilevel high-level
   */
  public String getSourceLabel() {
    return tokenString_SourceLabel != null ? tokenString_SourceLabel : "";
  }
  /**
   * Replaces the lexeme TargetLabel.
   * @param value The new value for the lexeme TargetLabel.
   * @apilevel high-level
   */
  public void setTargetLabel(String value) {
    tokenString_TargetLabel = value;
  }
  /**
   * @apilevel internal
   */
  protected String tokenString_TargetLabel;
  /**
   */
  public int TargetLabelstart;
  /**
   */
  public int TargetLabelend;
  /**
   * JastAdd-internal setter for lexeme TargetLabel using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme TargetLabel
   * @apilevel internal
   */
  public void setTargetLabel(beaver.Symbol symbol) {
    if(symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setTargetLabel is only valid for String lexemes");
    tokenString_TargetLabel = (String)symbol.value;
    TargetLabelstart = symbol.getStart();
    TargetLabelend = symbol.getEnd();
  }
  /**
   * Retrieves the value for the lexeme TargetLabel.
   * @return The value for the lexeme TargetLabel.
   * @apilevel high-level
   */
  public String getTargetLabel() {
    return tokenString_TargetLabel != null ? tokenString_TargetLabel : "";
  }
  /**
   * @apilevel internal
   */
  protected java.util.Set transitionOf_State_visited;
  /**
   * @attribute syn
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:39
   */
  public Transition transitionOf(State s) {
    Object _parameters = s;
    if(transitionOf_State_visited == null) transitionOf_State_visited = new java.util.HashSet(4);
    if (transitionOf_State_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attr: transitionOf in class: org.jastadd.ast.AST.SynDecl");
    }
    transitionOf_State_visited.add(_parameters);
    try {
        if (source() == s)
          return this;
        else
          return null;
      }
    finally {
      transitionOf_State_visited.remove(_parameters);
    }
  }
  /**
   * @apilevel internal
   */
  protected boolean source_visited = false;
  /**
   * @attribute syn
   * @aspect NameAnalysis
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/NameAnalysis.jrag:6
   */
  public State source() {
    if (source_visited) {
      throw new RuntimeException("Circular definition of attr: source in class: org.jastadd.ast.AST.SynDecl");
    }
    source_visited = true;
    try {  return lookup(getSourceLabel());  }
    finally {
      source_visited = false;
    }
  }
  /**
   * @apilevel internal
   */
  protected boolean target_visited = false;
  /**
   * @attribute syn
   * @aspect NameAnalysis
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/NameAnalysis.jrag:7
   */
  public State target() {
    if (target_visited) {
      throw new RuntimeException("Circular definition of attr: target in class: org.jastadd.ast.AST.SynDecl");
    }
    target_visited = true;
    try {  return lookup(getTargetLabel());  }
    finally {
      target_visited = false;
    }
  }
  protected void collect_contributors_State_altSuccessors() {
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:50
   */
    if (target() != null && source() != null) {
      {
        State ref = (State) (source());
        if (ref != null) {
          ref.State_altSuccessors_contributors().add(this);
        }
      }
    }
    super.collect_contributors_State_altSuccessors();
  }
  protected void collect_contributors_StateMachine_numberOfTransitionsColl() {
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:68
   */
      {
        StateMachine ref = (StateMachine) (theMachine());
        if (ref != null) {
          ref.StateMachine_numberOfTransitionsColl_contributors().add(this);
        }
      }
    super.collect_contributors_StateMachine_numberOfTransitionsColl();
  }
  protected void collect_contributors_StateMachine_errors() {
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:91
   */
    if (source() == null) {
      {
        StateMachine ref = (StateMachine) (theMachine());
        if (ref != null) {
          ref.StateMachine_errors_contributors().add(this);
        }
      }
    }
  /**
   * @attribute coll
   * @aspect Exercises
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:96
   */
    if (target() == null) {
      {
        StateMachine ref = (StateMachine) (theMachine());
        if (ref != null) {
          ref.StateMachine_errors_contributors().add(this);
        }
      }
    }
    super.collect_contributors_StateMachine_errors();
  }
  protected void collect_contributors_State_transitions() {
  /**
   * @attribute coll
   * @aspect Graph
   * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Graph.jrag:8
   */
    if (source() != null) {
      {
        State ref = (State) (source());
        if (ref != null) {
          ref.State_transitions_contributors().add(this);
        }
      }
    }
    super.collect_contributors_State_transitions();
  }
  protected void contributeTo_State_State_altSuccessors(Set<State> collection) {
    super.contributeTo_State_State_altSuccessors(collection);
    if(target() != null && source() != null)
      collection.add(target());
  }

  protected void contributeTo_StateMachine_StateMachine_numberOfTransitionsColl(Counter collection) {
    super.contributeTo_StateMachine_StateMachine_numberOfTransitionsColl(collection);
    collection.add(1);
  }

  protected void contributeTo_StateMachine_StateMachine_errors(Set<String> collection) {
    super.contributeTo_StateMachine_StateMachine_errors(collection);
    if(source() == null)
      collection.add("Missing declaration of "+getSourceLabel());
    if(target() == null)
      collection.add("Missing declaration of "+getTargetLabel());
  }

  protected void contributeTo_State_State_transitions(Set<Transition> collection) {
    super.contributeTo_State_State_transitions(collection);
    if(source() != null)
      collection.add(this);
  }

}
