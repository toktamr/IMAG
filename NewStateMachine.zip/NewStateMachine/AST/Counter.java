package AST;

import java.util.*;
/**
 * @ast class
 * @aspect Exercises
 * @declaredat /Users/toktamr/Dropbox/TJowner/toktam oslo/Toplas-IMAG/Jast add/StateMachine/spec/Exercises.jrag:75
 */
public class Counter extends java.lang.Object {

    private int value;


    public Counter() { value = 0; }


    public void add(int value) { this.value += value; }


    public int value() { return value; }


}
