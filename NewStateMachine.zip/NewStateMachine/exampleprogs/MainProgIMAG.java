package exampleprogs;
import AST.*;

public class MainProgram {

    public static void main(String[] args) {
        // Construct the AST
        StateMachine m = new StateMachine(1);
        m.addDeclaration(new State("S0"));
        m.addDeclaration(new State("S1"));
        m.addDeclaration(new State("S2"));
        m.addDeclaration(new Transition("auth=x", "S0", "S1"));
        m.addDeclaration(new Transition("auth=y", "S0", "S2"));
        m.addDeclaration(new State("S3"));
        m.addDeclaration(new State("S4"));
        m.addDeclaration(new Transition("permitted", "S1", "S3"));
        m.addDeclaration(new Transition("denied", "S2", "S3"));
        m.addDeclaration(new Transition("VE", "S3", "S4"));

        // instrument the program and check the policy.
                m.Instrumentation();

    }

}
